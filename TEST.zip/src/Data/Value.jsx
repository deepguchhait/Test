
const Data=[
  {id:1,name:"deep",Roll:340,student: true,Markes:90,img:"../public/react.svg"},
  {id:2,name:"sayan",Roll:340,student: true,Markes:90,img:"../public/vite.svg"},
  {id:3,name:"sujit",Roll:340,student: true,Markes:90,img:"../public/react.svg"},
  {id:4,name:"dev",Roll:340,student: true,Markes:90,img:"../public/vite.svg"},
  {id:5,name:"nayan",Roll:340,student: true,Markes:90,img:"../public/react.svg"},
  {id:6,name:"deep",Roll:340,student: true,Markes:90,img:"../public/vite.svg"},
  {id:7,name:"deep",Roll:340,student: true,Markes:90,img:"../public/react.svg"},
  {id:8,name:"deep",Roll:340,student: true,Markes:90,img:"../public/vite.svg"},
  {id:9,name:"deep",Roll:340,student: true,Markes:90,img:"../public/react.svg"},
  {id:10,name:"deep",Roll:340,student: true,Markes:59,img:"../public/vite.svg"}

];
export default Data;